# Blockfrontier — Alpha 0.1

A small original browser voxel sandbox built with HTML, CSS, vanilla JavaScript and Three.js.

## Run
Because the game uses JavaScript modules, open a terminal in this folder and run:

```bash
python -m http.server 8000
```

Then open http://localhost:8000 in a modern browser.

You need an internet connection for the Three.js module loaded from jsDelivr.

## Controls
- Click **ВОЙТИ В МИР** to enter pointer-lock mode.
- WASD: move
- Mouse: look around
- Space: jump
- Left mouse: remove a block
- Right mouse: place selected block
- 1–6 or mouse wheel: select block
- Esc: release mouse

## Features
- Procedurally generated small terrain
- Trees, grass, dirt, stone, wood, leaves and sand
- Block mining and placement
- Basic first-person movement and jumping
- Six-slot hotbar and simple inventory counts
- LocalStorage save/load

This is an alpha prototype. It intentionally uses a compact block grid and simple collision checks.
